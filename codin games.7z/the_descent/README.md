# THE DESCENT

## STATEMENT

A simple problem to try out the CodinGame platform: your program must find the
highest mountain out of a list of mountains.

## STORY

The Destiny ship is in danger: drawn towards the surface of an unknown planet,
it is at risk of crashing against towering mountains. Help Rick to destroy the
mountains... Save the Destiny!

## LINK

[THE DESCENT](https://www.codingame.com/training/easy/the-descent)
