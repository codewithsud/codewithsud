# Shadows-of-the-Knight---Episode-1
An exercise from coding games, aiming to practise the binary search in 2 dimensions: https://www.codingame.com/training/medium/shadows-of-the-knight-episode-1 
