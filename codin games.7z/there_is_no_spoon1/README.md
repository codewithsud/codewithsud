# THERE IS NO SPOON - EPISODE 1

## STATEMENT

The goal is to find, when they exist, the horizontal and vertical neighbors
nodes from a two dimensional array. The difficulty is in the number of nested
loops that this puzzle can make you write. Do not get lost!

## STORY

This puzzle is part of a series of two exercises proposed during the “There is
no Spoon” contest. Once done you should head towards the « There Is No Spoon -
Episode 2 » puzzle where things may just get a little thougher!

## LINK

[THERE IS NO SPOON - EPISODE 1](https://www.codingame.com/training/medium/there-is-no-spoon-episode-1)
