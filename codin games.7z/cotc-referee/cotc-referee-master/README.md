# cotc-referee
C Referee for CodinGames' "Coders of the Caribbean" contest
