# codingame-truncatedpyramid
https://www.codingame.com/ide/puzzle/highest-truncated-pyramid
