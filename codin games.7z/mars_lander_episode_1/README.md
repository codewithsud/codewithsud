## Mars lander - episode 1

* https://www.codingame.com/training/easy/mars-lander-episode-1