# Create the longest sequence of 1s

https://www.codingame.com/ide/puzzle/create-the-longest-sequence-of-1s
