## Shadow of the Knight - Episode 1

* https://www.codingame.com/training/medium/shadows-of-the-knight-episode-1