# Codingame
https://www.codingame.com/

## bot programming
Code Royal: https://www.codingame.com/multiplayer/bot-programming/code-royale

Ghost in the cell : https://www.codingame.com/multiplayer/bot-programming/ghost-in-the-cell
