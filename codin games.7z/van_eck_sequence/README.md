## Van eck sequence

* https://www.codingame.com/training/easy/van-ecks-sequence