## Temperature

* https://www.codingame.com/training/easy/temperatures