## Rectangle partition

* https://www.codingame.com/training/easy/rectangle-partition