## Bender episode 1

* https://www.codingame.com/training/medium/bender-episode-1