## ASCII art

* https://www.codingame.com/training/easy/ascii-art