# sudoku-validator

https://www.codingame.com/ide/puzzle/sudoku-validator