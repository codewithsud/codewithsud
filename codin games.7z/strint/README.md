# C-Libraries
Useful C libraries for (CodinGame, Project Euler)

## Libraries
* [strint](https://github.com/iamRusty/C-Libraries/tree/master/strint): a string to int parser library

## Libraries to be added
* dictionary: a python dictionary implementation in c
* csearch: implementation of search algorithms
* csort: implementation of sort algorithms
* spointer: a library containing high level structs/pointers 
