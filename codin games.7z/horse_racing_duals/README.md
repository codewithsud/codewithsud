## Horse racing duals

* https://www.codingame.com/training/easy/horse-racing-duals