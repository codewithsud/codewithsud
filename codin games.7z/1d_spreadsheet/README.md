## 1D spreadsheet

* https://www.codingame.com/training/easy/1d-spreadsheet