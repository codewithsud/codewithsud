# code-vs-zombies
My solution for the [Code vs Zombies Codingame optimization puzzle](https://www.codingame.com/multiplayer/optimization/code-vs-zombies), where I ranked 33/5061 (as BombayAGoGo).
