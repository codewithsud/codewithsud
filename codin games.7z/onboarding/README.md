# ONBOARDING

## STATEMENT

A tutorial mission for all newcomers: your program must find which of the two targets is the closest.

## STORY

Defend the planet with a big laser cannon from the invading insectoid alien ships.

## Link

[ONBOARDING](https://www.codingame.com/training/easy/onboarding)
