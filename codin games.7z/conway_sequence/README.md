# Conway sequence

* https://www.codingame.com/training/medium/conway-sequence
