## encryp decrypt enigma machine

* https://www.codingame.com/training/easy/encryptiondecryption-of-enigma-machine