# BRACKETS, EXTREME EDITION

## STATEMENT

You must determine whether a given expression has valid brackets. This means all
the parentheses (), square brackets [] and curly brackets {} must be correctly
paired & nested.

The expression does not contain whitespace characters.

## LINK

[BRACKETS, EXTREME EDITION](https://www.codingame.com/training/easy/brackets-extreme-edition)
