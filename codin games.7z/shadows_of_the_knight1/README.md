# SHADOWS OF THE KNIGHT - EPISODE 1

## STATEMENT

The goal of this puzzle is to guess the coordinate of a bomb (line and column of
a 2 dimensional array). You will have to make a guess at each step of the puzzle
and adjust it from given feedbacks. Of course, you have a limited number of
guess.

## STORY

Bombs, hostages, and a hero. This time, you are the hero. Your job is to find
the bombs before they explode! Don't worry, we got you covered, we've handed you
a heat detector set to recognize the thermal signature of the bombs. Easy? Let's
find out.

## LINK

[SHADOWS OF THE KNIGHT - EPISODE 1](https://www.codingame.com/training/medium/shadows-of-the-knight-episode-1)
