## Defibrillators

* https://www.codingame.com/training/easy/defibrillators