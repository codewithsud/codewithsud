## Chuck Norris

* https://www.codingame.com/training/easy/chuck-norris