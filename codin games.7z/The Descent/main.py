while True:
    mountains = [(int(input()), i) for i in range(8)]
    print(max(mountains)[1])
