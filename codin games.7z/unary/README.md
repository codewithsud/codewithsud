# UNARY

## STATEMENT

Your program must encode a string into a series of zeros.

A string is an encoded form of digital values and you have to transform those
values into a new format.

## STORY

Binary is good! But unary is much better!

Test your encoding skills in this easy puzzle where you will be asked to
transform a string into a “unary” string such as 0 00 000 0...

## LINK

[UNARY](https://www.codingame.com/training/easy/unary)
