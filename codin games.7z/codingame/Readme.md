CodinGame Seb

Mes solutions trouvées pour résoudre les défits de 
https://www.codingame.com/training
