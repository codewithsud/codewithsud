# Platinum-Rift-AI
Platinum Rift AI (https://www.codingame.com/)
