# TEMPERATURES

## STATEMENT

Your program must analyze records of temperatures to find the closest to zero.

## STORY

It's freezing cold out there! Will you be able to find the temperature closest
to zero in a set of temperatures readings?

## LINK

[TEMPERATURES](https://www.codingame.com/training/easy/temperatures)
