## Rocket Paper Scissors Lizard Spock

* https://www.codingame.com/training/easy/rock-paper-scissors-lizard-spock