## MIME type

* https://www.codingame.com/training/easy/mime-type