## Mayan calculation

* https://www.codingame.com/training/medium/mayan-calculation