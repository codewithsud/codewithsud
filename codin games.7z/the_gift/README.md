## The gift

* https://www.codingame.com/training/medium/the-gift