## telephone numbers

* https://www.codingame.com/training/medium/telephone-numbers