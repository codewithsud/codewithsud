## The river i

* https://www.codingame.com/training/easy/the-river-i-