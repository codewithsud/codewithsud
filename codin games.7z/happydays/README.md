# codingame-happydays
https://www.codingame.com/ide/puzzle/monday-tuesday-happy-days
