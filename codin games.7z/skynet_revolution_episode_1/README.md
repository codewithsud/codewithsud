## Skynet Revolution - episode 1

* https://www.codingame.com/training/medium/skynet-revolution-episode-1