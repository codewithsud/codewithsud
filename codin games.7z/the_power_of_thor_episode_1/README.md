## The power of Thor - episode 1

* https://www.codingame.com/training/easy/power-of-thor-episode-1