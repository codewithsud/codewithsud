## Bracket extreme edition

* https://www.codingame.com/training/easy/brackets-extreme-edition